NLPA =  Natural Language Processing Automation

NLPA is python package which build with help of Pandas and NLTK libray.
NLPA integrate the some methods of the above mentioned libray to ease the task of cleaning 
the text data.

Cleaning text data in which we have to perform the some basic task in repetition
like removing stowpword, word tokenizing ,lemmatizing , lowering text and etc... 
all these functionality can be achived in one single call.

In this project we simply call the fucntions  cleanData and passing parameter into it and it return the 
clean text or we can call each individual fucntions and perform our cleaning as per our need.
